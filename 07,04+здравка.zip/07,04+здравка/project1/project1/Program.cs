﻿// See https://aka.ms/new-console-template for more information
using project1.View;

namespace project1
{
    public class Program 
    {
        static async Task Main(string[] args)
        {
            Display display = new Display();
            await display.ShowMethod();
        }  
    }

}

