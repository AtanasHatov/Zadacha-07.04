﻿using project1.Controler;
using project1.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.View
{
    public class Display
    {
        AuthorControler authorControler=new AuthorControler();      
        BookControler bookControler=new BookControler();

        public async Task ShowMethod()
        {
            while (true)
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1 - End");
                Console.WriteLine("2 - 5 Authors");
                Console.WriteLine("3 - 5 Books");
                Console.WriteLine("4 - заглавията на всички книги с цена от 20 до 25 лева");
                Console.WriteLine("5 - заглавията на всички книги, които са с по-малко от 10 символа");
                Console.WriteLine("6 - заглавията на всички книги, които са с по-малко от 10 символа ");
                Console.WriteLine("7 - първо име и фамилия на всички български автори");
                Console.WriteLine("8 - имената на всички автори с националност, въведена от конзолата");
                Console.WriteLine("9 - заглавията на всички книги на издателсто въведено от конзолата");
                Console.WriteLine("10 - заглавията на всички книги на издателсто въведено от конзолата");

                int n=int.Parse(Console.ReadLine());

                if (n == 1)
                {
                    break;
                }
                switch (n)
                {
                    case 1:
                        Console.WriteLine();
                        break;
                        case 2:
                        for (int i = 0;i<=5;i++)
                        {
                            string first = Console.ReadLine();
                            string surname = Console.ReadLine();
                            string nation = Console.ReadLine();
                            List<Book> books1 = new List<Book>();
                            await authorControler.AddAuthor(first, surname, nation, books1);
                        }
                        break;
                        case 3:
                        for (int i = 0; i <= 5; i++)
                        {
                            string title = Console.ReadLine();
                            int authot=int.Parse(Console.ReadLine());
                            string publisher = Console.ReadLine();
                            decimal price=decimal.Parse(Console.ReadLine());
                            await bookControler.AddBook(title,authot,publisher,price);
                        }
                        break;
                        case 4:
                        List<Book>books2 = await bookControler.Book2025();
                        if (books2.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Book book in books2)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        break;
                    case 5:
                        List<Book> book3 = await bookControler.BookLength10();
                        if (book3.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Book book in book3)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        break;

                        case 6:
                            List<Book>book4 = await bookControler.BookLength10();
                        if (book4.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Book book in book4)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        break;

                        case 7:
                            List<Author> author2=await authorControler.AuthorsBulgary();
                        if (author2.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Author author in author2)
                            {
                                Console.WriteLine($"{author.FirstName} - {author.LastName}");
                            }
                        }
                        break;

                        case 8:
                        string nation=Console.ReadLine();
                        List<Author> author3 = await authorControler.AuthorsNational(nation);
                        if (author3.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Author author in author3)
                            {
                                Console.WriteLine($"{author.FirstName} - {author.LastName}");
                            }
                        }
                        break;
                        case 9:
                        string publisher=Console.ReadLine();
                        List<Book> book5 = await bookControler.BooksPublished(publisher);
                        if (book5.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Book book in book5)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        break;
                    case 10:
                        string name = Console.ReadLine();
                        List<Book> book6 = await bookControler.BooksSurname(name);
                        if (book6.Count == 0)
                        {
                            Console.WriteLine("Prazno");
                        }
                        else
                        {
                            foreach (Book book in book6)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        break;
                    default: Console.WriteLine("Error");
                        break;
                }

            }
        }
    }
}
