﻿using project1.Data;
using project1.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project1.Data.Entities;
using project1.Data;
using Microsoft.EntityFrameworkCore;

namespace project1.Controler
{
    public class BookControler
    {
        LibraryDBContext dbContext = new LibraryDBContext();
        public async Task AddBook(string title, int author,string publusher, decimal price)
        {
            Book books = new Book()
            {
                Title=title,
                AuthorId=author,
                Publisher=publusher,
                Price=price
            };

            dbContext.Books.Add(books);
        }

       public async Task<List<Book>> Book2025()
        {
            var books = await dbContext.Books.Where(b => b.Price >= 20 && b.Price <= 25).ToListAsync();
            return books;
        }

        public async Task<List<Book>> BookLength10()
        {
            var books = await dbContext.Books.Where(b=>b.Title.Length<10).ToListAsync();
            return books;
        }

        public async Task<List<Book>> BooksPublished(string publisher)
        {
            var books = await dbContext.Books.Where(a => a.Publisher==publisher).ToListAsync();
            return books;
        }

        public async Task<List<Book>> BooksSurname(string surname)
        {
            var books = await dbContext.Books.Where(a => a.Authors.LastName==surname).ToListAsync();
            return books;
        }
    }
}
