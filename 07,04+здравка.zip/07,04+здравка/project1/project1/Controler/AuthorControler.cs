﻿using Microsoft.EntityFrameworkCore;
using project1.Data;
using project1.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Controler
{
    public class AuthorControler
    {
        LibraryDBContext dbContext = new LibraryDBContext();

        public async Task AddAuthor(string first,string surname, string nation, List<Book> books)
        {
            Author author = new Author()
            {
                FirstName = first,
                LastName = surname,
                Nationality = nation,
                Books = books
            };  
            dbContext.Authors.Add(author);
                
        }

        public async Task<List<Author>> AuthorsBulgary()
        {
            var authors=await dbContext.Authors.Where(a=>a.Nationality=="bulgarian").ToListAsync();
            return authors;
        }

        public async Task<List<Author>> AuthorsNational(string national)
        {
            var authors = await dbContext.Authors.Where(a => a.Nationality==national).ToListAsync();
            return authors;
        }
    }
}
